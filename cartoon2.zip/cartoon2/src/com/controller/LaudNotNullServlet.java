package com.controller;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.service.LaudService;

public class LaudNotNullServlet extends HttpServlet {
	@Override
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		int id = Integer.parseInt(request.getParameter("id"));
		int cid = Integer.parseInt(request.getParameter("cid"));
		int laudonoff = Integer.parseInt(request.getParameter("laudonoff"));
		System.out.println("Servlet�й���������" + laudonoff);
		LaudService laudService = new LaudService();
		if (laudonoff == 1) {
			laudonoff = 0;
			System.out.println("Servlet�й���������");
			laudService.updateLaud(id, cid, laudonoff);
		}else if (laudonoff == 0) {
			laudonoff = 1;
			laudService.updateLaud(id, cid, laudonoff);
		}
		response.sendRedirect("AdminHtmlJsp/AdminHome.jsp");
	}
	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		doGet(request, response);
	}
}
