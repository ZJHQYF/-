package com.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Date;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.entity.allCartoon;
import com.service.AllCartoonService;

public class AddCartoonServlet extends HttpServlet {
	@Override
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		doPost(request, response);
	}
	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		PrintWriter out = response.getWriter();
		HttpSession session = request.getSession();
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
		int typeid = Integer.parseInt(request.getParameter("typeid"));
		String cauthor = request.getParameter("cauthor");
		String ctitle = request.getParameter("ctitle");
		String pic = request.getParameter("pic");
		String url = request.getParameter("url");
		String issuedateString = request.getParameter("issuedate");
		System.out.println("����=====" + issuedateString);
		java.util.Date issuedateUtil;
		
		
		
		String updateslot = request.getParameter("updateslot");
		String issuer = request.getParameter("issuer");
		String publish = request.getParameter("publish");
		int stock = Integer.parseInt(request.getParameter("stock"));
		String content = request.getParameter("content");
		allCartoon allcartoon = new allCartoon();
		allcartoon.setTypeid(typeid);
		allcartoon.setCtitle(ctitle);
		allcartoon.setPic(pic);
		allcartoon.setUrl(url);
		try {
			issuedateUtil = sdf.parse(issuedateString);
			java.sql.Date issuedate = new java.sql.Date(issuedateUtil.getTime());
			allcartoon.setIssueDate(issuedate);
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		allcartoon.setUpdatesLot(updateslot);
		allcartoon.setIssure(issuer);
		allcartoon.setPublish(publish);
		allcartoon.setCauthor(cauthor);
		allcartoon.setStock(stock);
		allcartoon.setContent(content);
		AllCartoonService allCartoonService = new AllCartoonService();
		int row = allCartoonService.addCartoon(allcartoon);
		if (row > 0) {
			out.println("���ӳɹ���3��󷵻�����ҳ��");
			ArrayList<allCartoon> allCartoonList = allCartoonService.select_allCartoon();
			session.setAttribute("allCartoonsList", allCartoonList);
			response.setHeader("refresh", "3,URL = AddCartoon/AddCartoon.jsp");
		}else{
			out.println("����ʧ�ܣ�3��󷵻�����ҳ��");
			response.setHeader("refresh", "3,URL = AddCartoon/AddCartoon.jsp");
		}
	}
}
