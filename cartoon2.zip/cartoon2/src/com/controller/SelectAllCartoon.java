package com.controller;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.entity.allCartoon;
import com.service.AllCartoonService;

public class SelectAllCartoon extends HttpServlet {
	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		doGet(request, response);
	}
	
	@Override
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		HttpSession session = request.getSession();
		AllCartoonService allCartoonService = new AllCartoonService();
		ArrayList<allCartoon> allCartoonsList = allCartoonService.select_allCartoon();
		
		String pageNoString = request.getParameter("pageNo");//�ڼ�ҳ
		System.out.println("ҳ����" + pageNoString);
		int pageNo = 0; 
		int pageNum = 5;//ÿҳ����
		//CartoonService cartoonService = new CartoonService();
		//ArrayList<Cartoon> allCartoons = allCartoonService.allCartoon();
		int allPage = allCartoonsList.size();//������
		int pageAllNum = allPage % pageNum == 0 ? allPage / pageNum : allPage / pageNum + 1;
		System.out.println("����ҳ��" + pageAllNum);
		if (pageNoString == null) {
			pageNo = 1;
		}else {
			pageNo = Integer.parseInt(pageNoString);
		}
		ArrayList<allCartoon> cartoonLimit = allCartoonService.allCartoonLimit(pageNo, pageNum);
		System.out.println("��ǰҳ��" + pageNo);
		session.setAttribute("pageNo", pageNo);
		session.setAttribute("pageAllNum", pageAllNum);
		session.setAttribute("cartoonLimit", cartoonLimit);
		session.setAttribute("allCartoonsList", cartoonLimit);
		request.getRequestDispatcher("AdminHtmlJsp/AdminHome.jsp").forward(request, response);
		
	}
}
