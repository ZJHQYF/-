package com.controller;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.entity.allCartoon;
import com.service.AllCartoonService;

public class FirstVisitServlet extends HttpServlet {
	//��ӭҳ�棬��������ת����ҳ
	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		doGet(request, response);
	}
	@Override
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		HttpSession session = request.getSession();
		AllCartoonService allCartoonService = new AllCartoonService();
		ArrayList<allCartoon> indexCartoonList = allCartoonService.select_allCartoon();
		session.setAttribute("indexCartoonList", indexCartoonList);
		session.setAttribute("VipSessionName", null);
		System.out.println("��ü��������");
		request.getRequestDispatcher("index.jsp").forward(request, response);
	}
}
