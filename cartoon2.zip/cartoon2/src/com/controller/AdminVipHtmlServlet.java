package com.controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.faces.application.Application;
import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.entity.allCartoon;
import com.service.AllCartoonService;

public class AdminVipHtmlServlet extends HttpServlet {
	@Override
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		PrintWriter out = response.getWriter();
		String url = request.getParameter("url");
		Integer cid = Integer.parseInt(request.getParameter("cid"));
		//����cid�Ȳ�ѯ������
		AllCartoonService allCartoonService = new AllCartoonService();
		allCartoon cartoonList = allCartoonService.select_allCartoon_toCid(cid);
		int num_of_visit = cartoonList.getNum_Of_Visit();
		num_of_visit++;
		out.println(num_of_visit);
		allCartoonService.updateCartoon(num_of_visit, cid);
		System.out.println("�����¼�洢���ʴ�����Servlet");
		response.sendRedirect(url);
	}
	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		doGet(request, response);
	}
}
