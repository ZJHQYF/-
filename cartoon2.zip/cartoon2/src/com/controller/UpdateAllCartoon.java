package com.controller;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.entity.allCartoon;
import com.service.AllCartoonService;

public class UpdateAllCartoon extends HttpServlet {
	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		HttpSession session = request.getSession();
		allCartoon allcartoon = (allCartoon)session.getAttribute("allCartoons");
		int cid = allcartoon.getCid();
		String publish = (String)request.getParameter("publish");
		String upDatesLot = (String) request.getParameter("updateslot");
		String content = (String) request.getParameter("content");
		int stock = Integer.parseInt(request.getParameter("stock").toString());
		allCartoon cartoon = new allCartoon();
		cartoon.setCid(cid);
		cartoon.setPublish(publish);
		cartoon.setContent(content);
		cartoon.setStock(stock);
		cartoon.setUpdatesLot(upDatesLot);
		AllCartoonService allCartoonService = new AllCartoonService();
		int row = allCartoonService.updateAllCartoon(cartoon);
		System.out.println("bb");
		if (row > 0) {
			System.out.println("aa");
			allcartoon = allCartoonService.select_allCartoon_toCid(cid);
			ArrayList<allCartoon> allCartoonsList = allCartoonService.select_allCartoon();
			System.out.println("kucun="+allcartoon.getStock());
			session.setAttribute("allCartoons", allcartoon);
			session.setAttribute("allCartoonsList", allCartoonsList);
			//response.sendRedirect("");
			request.getRequestDispatcher("AdminHtmlJsp/ManageIframe.jsp").forward(request, response);
		}
	}
	@Override
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		doPost(request, response);
	}
}
