package com.controller;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.entity.allCartoon;
import com.service.AllCartoonService;

public class DeleteCartoonServlet extends HttpServlet {
	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		doGet(request, response);
	}
	@Override
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		int cid = Integer.parseInt(request.getParameter("cid"));
		HttpSession session = request.getSession();
		AllCartoonService allCartoonService = new AllCartoonService();
		int row = allCartoonService.deleteCartoon(cid);
		if (row > 0) {
			ArrayList<allCartoon> allCartoons = allCartoonService.select_allCartoon();
			session.setAttribute("allCartoonsList", allCartoons);
		}
		request.getRequestDispatcher("/SelectAllCartoon").forward(request, response);
	}
}
