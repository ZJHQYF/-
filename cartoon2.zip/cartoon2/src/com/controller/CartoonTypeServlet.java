package com.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.entity.CartoonType;
import com.service.CartoonTypeService;

public class CartoonTypeServlet extends HttpServlet {
	@Override
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		doPost(request, response);
	}
	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
			PrintWriter out = response.getWriter();
			HttpSession session = request.getSession();
			CartoonTypeService cartoonTypeService = new CartoonTypeService();
			ArrayList<CartoonType> cartoonTypeList = cartoonTypeService.selectAllCartoonType();
			session.setAttribute("cartoonTypeList", cartoonTypeList);
			System.out.println("Servletyҳ��");
			//��תҳ��
			String AdminUserName = (String)session.getAttribute("AdminUserName");
			if (AdminUserName == null && AdminUserName.equals("")) {
				request.getRequestDispatcher("/cartoon2/FirstVisitServlet");
			}else {
				request.getRequestDispatcher("AddCartoon/AddCartoon.jsp").forward(request, response);
			}
			
	}
}
