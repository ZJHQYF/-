package com.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.net.Inet4Address;
import java.net.InetAddress;
import java.util.ArrayList;

import javax.faces.application.Application;
import javax.jms.Session;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.servlet.jsp.PageContext;

import com.entity.Cartoon;
import com.entity.User2;
import com.entity.allCartoon;
import com.service.AdminService;
import com.service.AllCartoonService;
import com.service.User2Service;

public class DoLogin extends HttpServlet {

	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		request.setCharacterEncoding("utf-8");
		doPost(request, response);
	}


	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		InetAddress address = InetAddress.getLocalHost();
		System.out.println("�������� ===" + address.getHostName());
		System.out.println("����IP===" + address.getHostAddress());
		response.setContentType("text/html;charset=utf-8");
		request.setCharacterEncoding("utf-8");
		response.setCharacterEncoding("utf-8");
		PrintWriter out = response.getWriter();
		//����������ʾ
		//ֻ�����̿���
		//1���յ��û��ڽ����¼ʱ������û��������롢��Ա\����Ա
		//����ǹ���Ա�����ù���Ա�ĵ�¼����
		//�����¼ʧ�� �ص�index.jsp,����ɹ�������Ա�������Աҳ�棬��Ա�����Աҳ��
		
		HttpSession session = request.getSession();
		String userName = request.getParameter("userName");
		String userPwd = request.getParameter("userPwd");
		String userType = request.getParameter("userType");
		System.out.println("�û�����" + userName);
		System.out.println("���룺" + userPwd);
		System.out.println("�û����ͣ�" + userType);
		if (userType == null) {
			userType = "1";
		}
		if (userName == null || userPwd == null || userName.equals("") || userPwd.equals("")) {
			session.setAttribute("userId", 0);
			session.setAttribute("VipSessionName", "δ��¼");
			response.sendRedirect("index.jsp");
		}else {
			Integer online = (Integer)this.getServletContext().getAttribute("online");
			if(online == null){
				online = 0;
			}
				online++;
			this.getServletContext().setAttribute("online", online);
			boolean isSeccess = false;
			if (userType.equals("1")) {
				//����Ա��¼
				AdminService adminService = new AdminService();
				isSeccess = adminService.select_admin(userName, userPwd);
				System.out.println("����ԱisSeccess==========" + isSeccess);
			}else if (userType.equals("0")) {
				//��Ա��¼
				User2Service user2Service = new User2Service();
				User2 user2 = user2Service.login(userName, userPwd);
				if (user2 != null) {
					isSeccess = true;
				}
			}else {
				//�Ȳ��ǹ���Ա��Ҳ���ǻ�Ա�ص���¼ҳ��
				response.sendRedirect("/cartoon2/index.jsp");
			}
			//�����½�ɹ�������Ա�������Աҳ�棬��Ա�����Աҳ��
			if (isSeccess == false) {
				response.sendRedirect("/cartoon2/index.jsp");
			}else {
				
				if (userType.equals("1")) {
					//����Ա
					//ת��
					/*
					 * 
					 
					AllCartoonService allCartoonService = new AllCartoonService();
					ArrayList<allCartoon> allCartoonsList = allCartoonService.select_allCartoon();
					
					String pageNoString = request.getParameter("pageNo");//�ڼ�ҳ
					System.out.println("ҳ����" + pageNoString);
					int pageNo = 0; 
					int pageNum = 5;//ÿҳ����
					//CartoonService cartoonService = new CartoonService();
					//ArrayList<Cartoon> allCartoons = allCartoonService.allCartoon();
					int allPage = allCartoonsList.size();//������
					int pageAllNum = allPage % pageNum == 0 ? allPage / pageNum : allPage / pageNum + 1;
					System.out.println("����ҳ��" + pageAllNum);
					if (pageNoString == null) {
						pageNo = 1;
					}else {
						pageNo = Integer.parseInt(pageNoString);
					}
					ArrayList<allCartoon> cartoonLimit = allCartoonService.allCartoonLimit(pageNo, pageNum);
					System.out.println("��ǰҳ��" + pageNo);
					session.setAttribute("pageNo", pageNo);
					session.setAttribute("pageAllNum", pageAllNum);
					session.setAttribute("cartoonLimit", cartoonLimit);
					session.setAttribute("allCartoonsList", cartoonLimit);
					*/
					session.setAttribute("AdminUserName", userName);
					session.setAttribute("userType", userType);
					session.setAttribute("userId", 0);
					request.getRequestDispatcher("/SelectAllCartoon").forward(request, response);
				}else {
						User2Service user2Service = new User2Service();
						User2 user2 = user2Service.login(userName, userPwd);
						 int id = user2.getId();
						session.setAttribute("userId", id);
						//System.out.println("Servlet�еĻ�Ա���" + id);
						System.out.println("�û����=====" + id);
					
					session.setAttribute("VipSessionName", userName);
					request.setAttribute("VipUserName", userName);
					request.getRequestDispatcher("index.jsp").forward(request, response);
				}
			}
			
		}
	}

}
