package com.entity;

public class V_LaudSum {
	private int cid;
	private int laudSum;
	public int getCid() {
		return cid;
	}
	public void setCid(int cid) {
		this.cid = cid;
	}
	public int getLaudSum() {
		return laudSum;
	}
	public void setLaudSum(int laudSum) {
		this.laudSum = laudSum;
	}
	
}
