package com.entity;

import java.sql.Date;

public class allCartoon {
	private int cid;//���
	private int typeid;//��������
	private String ctitle;//��������
	private String cauthor;//��������
	private String content;//���ݼ��
	private String pic;//����ͼƬ
	private String url;//�Ķ�����
	private Date issueDate;//��������
	private String updatesLot;//����ʱ���
	private String issure;//׫����
	private String publish;//������
	private int stock;//�����
	private int num_Of_Visit;//���ʴ���
	public int getNum_Of_Visit() {
		return num_Of_Visit;
	}
	public void setNum_Of_Visit(int num_Of_Visit) {
		this.num_Of_Visit = num_Of_Visit;
	}
	public int getCid() {
		return cid;
	}
	public void setCid(int cid) {
		this.cid = cid;
	}
	public int getTypeid() {
		return typeid;
	}
	public void setTypeid(int typeid) {
		this.typeid = typeid;
	}
	public String getCtitle() {
		return ctitle;
	}
	public void setCtitle(String ctitle) {
		this.ctitle = ctitle;
	}
	public String getCauthor() {
		return cauthor;
	}
	public void setCauthor(String cauthor) {
		this.cauthor = cauthor;
	}
	public String getContent() {
		return content;
	}
	public void setContent(String content) {
		this.content = content;
	}
	public String getPic() {
		return pic;
	}
	public void setPic(String pic) {
		this.pic = pic;
	}
	public String getUrl() {
		return url;
	}
	public void setUrl(String url) {
		this.url = url;
	}
	public Date getIssueDate() {
		return issueDate;
	}
	public void setIssueDate(Date issueDate) {
		this.issueDate = issueDate;
	}
	public String getUpdatesLot() {
		return updatesLot;
	}
	public void setUpdatesLot(String updatesLot) {
		this.updatesLot = updatesLot;
	}
	public String getIssure() {
		return issure;
	}
	public void setIssure(String issure) {
		this.issure = issure;
	}
	public String getPublish() {
		return publish;
	}
	public void setPublish(String publish) {
		this.publish = publish;
	}
	public int getStock() {
		return stock;
	}
	public void setStock(int stock) {
		this.stock = stock;
	}
	
}
