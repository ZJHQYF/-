package com.service;

import java.util.ArrayList;

import com.dao.CartoonTypeDAO;
import com.entity.CartoonType;

public class CartoonTypeService {
	private CartoonTypeDAO cartoonTypeDAO = new CartoonTypeDAO();
	//��ѯ������������
	public ArrayList<CartoonType> selectAllCartoonType(){
		ArrayList<CartoonType> allCartoonTypes = cartoonTypeDAO.selectCartoonTypes();
		return allCartoonTypes;
	}
	//����typeid��ѯ
	public CartoonType selectCartoonTypeToTypeId(int typeid){
		CartoonType cartoonType = cartoonTypeDAO.selectCartoonTypeToTypsid(typeid);
		return cartoonType;
	}
	//����typeid�޸�typeame
	public int updateCartoonType(int typeId, String typeName){
		System.out.println("Type�У�" + typeId);
		System.out.println("Type�У�" + typeName);
		return cartoonTypeDAO.updateCartoonType(typeId, typeName);
	}
	
	//������������
	public int insertCartoonType(CartoonType cartoonType){
		return cartoonTypeDAO.insertCartoonType(cartoonType);
	}
	
	public int deleteCartoonType(int typeId){
		return cartoonTypeDAO.deleteCartoonType(typeId);
	}
}
