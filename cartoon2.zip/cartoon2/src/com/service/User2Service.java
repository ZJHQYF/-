package com.service;

import com.dao.User2DAO;
import com.entity.User2;

public class User2Service {
	User2DAO user2Dao = new User2DAO();
	public User2 login(String name, String pwd){
		User2 user2 = user2Dao.select(name, pwd);
		return user2;
	}
}
