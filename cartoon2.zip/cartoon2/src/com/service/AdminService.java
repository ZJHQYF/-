package com.service;

import com.dao.AdminDAO;
import com.entity.Admin;

public class AdminService {
	private AdminDAO adminDAO = new AdminDAO();
	public boolean select_admin(String userName, String userPwd){
		System.out.println("AdminService���Ƿ�====" + userName+ "and" + userPwd);
		Admin admin = adminDAO.select_admin(userName, userPwd);
		System.out.println("AdminService�е�admin====" + admin);
		if (admin == null) {
			return false;
		}else {
			return true;
		}
	}
}
