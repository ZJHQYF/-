package com.service;

import com.dao.V_LaudSumDAO;
import com.entity.V_LaudSum;

public class V_LaudSumService {
	private V_LaudSumDAO v_LaudSumDAO = new V_LaudSumDAO();
	//��ѯ��ͼ�����ܵĵ�����
	public V_LaudSum selectLaudSum(int cid){
		V_LaudSum v_LaudSum = v_LaudSumDAO.selectLaudSum(cid);
		return v_LaudSum;
	}
}
