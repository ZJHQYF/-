package com.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.entity.LaudEntity;
import com.entity.V_LaudSum;

public class V_LaudSumDAO {
	//��ѯ��ͼ
	public V_LaudSum selectLaudSum(int cid){
		Connection connection = BaseDAO.getConnection();
		if (connection == null) {
			return null;
		}else {
			PreparedStatement pstmt = null;
			ResultSet resultSet = null;
			
			try {
				String sql = "select * from v_laudsum where cid = ?";
				pstmt = connection.prepareStatement(sql);
				pstmt.setInt(1, cid);
				resultSet = pstmt.executeQuery();
				if (resultSet != null && resultSet.next()) {
					V_LaudSum v_LaudSum = new V_LaudSum();
					v_LaudSum.setCid(resultSet.getInt("cid"));
					v_LaudSum.setLaudSum(resultSet.getInt("laudsum"));
					return v_LaudSum;
				}
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				return null;
			}finally{
				BaseDAO.close(connection, pstmt, resultSet);
			}
		}
		return null;
	}
	
}
