package com.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.entity.LaudEntity;

public class LaudDAO {
	//���޲���
	//��ѯ���ݣ���Ҫ����ҳ����ʾ��������жϣ�
	public LaudEntity selestLaud(int id, int cid){
		Connection connection = BaseDAO.getConnection();
		System.out.println("LaudDAO��connection" + connection);
		if (connection != null) {
			PreparedStatement pstmt = null;
			ResultSet resultSet = null;
			try {
				String sql = "select * from laud where id = ? and cid = ?";
				pstmt = connection.prepareStatement(sql);
				pstmt.setInt(1, id);
				pstmt.setInt(2, cid);
				resultSet = pstmt.executeQuery();
				if (resultSet != null && resultSet.next()) {
					System.out.println("�Ƿ�ִ��===========");
					LaudEntity laudEntity = new LaudEntity();
					laudEntity.setId(resultSet.getInt("id"));
					laudEntity.setCid(resultSet.getInt("cid"));
					laudEntity.setLaudOnOff(resultSet.getInt("laudonoff"));
					return laudEntity;
				}
				return null;
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}finally{
				BaseDAO.close(connection, pstmt, resultSet);
			}
			
		}
		return null;
	}
	//��������
	public int  insertInToLaud(int id, int cid, int laudonoff) {
		int row = 0;
		Connection connection = BaseDAO.getConnection();
		if (connection == null) {
			return row;
		}else {
			PreparedStatement pstmt = null;
			ResultSet resultSet = null;
			
			try {
				String sql = "insert into laud(id,cid,laudonoff) values(?, ?, ?)";
				pstmt = connection.prepareStatement(sql);
				pstmt.setInt(1, id);
				pstmt.setInt(2, cid);
				pstmt.setInt(3, laudonoff);
				row = pstmt.executeUpdate();
				return row;
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}finally{
				BaseDAO.close(connection, pstmt, resultSet);
			}
		}
		return row;
	}
	//�޸�laudonoff����
	public int updateLaud(int id, int cid, int laudonoff){
		Connection connection = BaseDAO.getConnection();
		int row = 0;
		if (connection != null) {
			PreparedStatement pstmt = null;
			ResultSet resultSet = null;
			
			try {
				String sql = "update laud set laudonoff = ? where id = ? and cid = ?";
				pstmt = connection.prepareStatement(sql);
				pstmt.setInt(1, laudonoff);
				pstmt.setInt(2, id);
				pstmt.setInt(3, cid);
				row = pstmt.executeUpdate();
				return row;
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}finally{
				BaseDAO.close(connection, pstmt, resultSet);
			}
		}
		return row;
	}
}
