package com.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.entity.Admin;

public class AdminDAO {
	//��ѯ
	@SuppressWarnings("null")
	public Admin select_admin(String userName, String userPwd){
		Connection connection = BaseDAO.getConnection();
		System.out.println("AdminDao��connection+++++" + connection);
		if (connection == null) {
			return null;
		}else {
			PreparedStatement pstmt = null;
			ResultSet rs = null;
			try {
				String sql = "select * from admin where username = ? and userpwd = ?";
				pstmt = connection.prepareStatement(sql);
				pstmt.setString(1, userName);
				pstmt.setString(2, userPwd);
				rs = pstmt.executeQuery();
				if (rs != null && rs.next()) {
					Admin admin = new Admin();
					admin.setId(rs.getInt("id"));
					admin.setUserName(rs.getString("username"));
					admin.setUserPwd(rs.getString("userpwd"));
					admin.setTrueName(rs.getString("truename"));
					return admin;
				}
				
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				return null;
			}finally{
				BaseDAO.close(connection, pstmt, rs);
			}
		}
		return null;
	}
}
