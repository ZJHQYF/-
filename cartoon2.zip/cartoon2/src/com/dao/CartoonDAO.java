package com.dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import javax.swing.text.html.HTMLDocument.HTMLReader.ParagraphAction;

import com.entity.Cartoon;
import com.entity.allCartoon;
import com.sun.corba.se.spi.orbutil.fsm.Guard.Result;
import com.sun.javafx.image.IntPixelAccessor;

public class CartoonDAO {
	//��������typeid��ѯ����
	public ArrayList<Cartoon> arrayCartoons(int typeid){
		Connection connection = BaseDAO.getConnection();
		if (connection == null) {
			return null;
		}else {
			PreparedStatement preparedStatement = null;
			ResultSet resultSet = null;
			try {
				String sql = "select ctitle,cauthor from cartoon where typeid = ?";
				preparedStatement = connection.prepareStatement(sql);
				preparedStatement.setInt(1, typeid);
				resultSet = preparedStatement.executeQuery();
				if (resultSet != null) {
					ArrayList<Cartoon> arrayList = new ArrayList<Cartoon>();
					while (resultSet.next()) {
						Cartoon cartoon = new Cartoon();
						cartoon.setCtitle(resultSet.getString("ctitle"));
						cartoon.setCauthor(resultSet.getString("cauthor"));
						arrayList.add(cartoon);
					}
					return arrayList;
				}else {
					return null;
				}
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				return null;
			}finally{
				BaseDAO.close(connection, preparedStatement, resultSet);
			}
		}
	}
	//��������ѯ��������
	public ArrayList<allCartoon> select_allCartoon(){
		Connection connection = BaseDAO.getConnection();
		if (connection == null) {
			return null;
		}else {
			Statement statement = null;
			ResultSet resultSet = null;
			try {
				String sql = "select * from cartoon";
				statement = connection.createStatement();
				resultSet = statement.executeQuery(sql);
				if (resultSet != null&&resultSet.next()) {
					resultSet = statement.executeQuery(sql);//����ʦ��ν��
					ArrayList<allCartoon> arrayList = new ArrayList<allCartoon>();
					while (resultSet.next()) {
						allCartoon cartoon = new allCartoon();
						cartoon.setCid(resultSet.getInt("cid"));
						cartoon.setTypeid(resultSet.getInt("typeid"));
						cartoon.setCtitle(resultSet.getString("ctitle"));
						cartoon.setCauthor(resultSet.getString("cauthor"));
						cartoon.setContent(resultSet.getString("content"));
						cartoon.setPic(resultSet.getString("pic"));
						cartoon.setUrl(resultSet.getString("url"));
						cartoon.setIssueDate(resultSet.getDate("issuedate"));
						cartoon.setUpdatesLot(resultSet.getString("updateslot"));
						cartoon.setIssure(resultSet.getString("issuer"));
						cartoon.setPublish(resultSet.getString("publish"));
						cartoon.setStock(resultSet.getInt("stock"));
						arrayList.add(cartoon);
					}
					return arrayList;
				}
				return null;
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				return null;
			}finally{
				BaseDAO.close(connection, null, resultSet);
			}
		}
	}
	
	//��ҳ��ѯ����
	public ArrayList<allCartoon> selectAllCartoonLimit(int pageNo, int pageNum){//pageNo�ڼ�ҳ��pageNum������
		Connection connection = BaseDAO.getConnection();
		if (connection != null) {
			PreparedStatement pstmt = null;
			ResultSet resultSet = null;
			
			try {
				String sql = "select * from cartoon limit ? , ?";
				pstmt = connection.prepareStatement(sql);
				pstmt.setInt(1, (pageNo - 1) * pageNum);
				pstmt.setInt(2, pageNum);
				resultSet = pstmt.executeQuery();
				if (resultSet != null) {
					ArrayList<allCartoon> arrayList = new ArrayList<allCartoon>();
					while (resultSet.next()) {
						allCartoon cartoon = new allCartoon();
						cartoon.setCid(resultSet.getInt("cid"));
						cartoon.setTypeid(resultSet.getInt("typeid"));
						cartoon.setCtitle(resultSet.getString("ctitle"));
						cartoon.setCauthor(resultSet.getString("cauthor"));
						cartoon.setContent(resultSet.getString("content"));
						cartoon.setPic(resultSet.getString("pic"));
						cartoon.setUrl(resultSet.getString("url"));
						cartoon.setIssueDate(resultSet.getDate("issuedate"));
						cartoon.setUpdatesLot(resultSet.getString("updateslot"));
						cartoon.setIssure(resultSet.getString("issuer"));
						cartoon.setPublish(resultSet.getString("publish"));
						cartoon.setStock(resultSet.getInt("stock"));
						arrayList.add(cartoon);
						
					}
					return arrayList;
				}
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				return null;
			}finally{
				BaseDAO.close(connection, pstmt, resultSet);
			}
		}else {
			return null;
		}
		return null;
		
	}
	
	
	//����cid��ѯ������Ϣ
	public allCartoon select_allCartoon_toCid(int cid){
		Connection connection = BaseDAO.getConnection();
		if (connection == null) {
			return null;
		}else {
			PreparedStatement pstmt = null;
			ResultSet resultSet = null;
			
			try {
				String sql = "select * from cartoon where cid = ?";
				pstmt = connection.prepareStatement(sql);
				pstmt.setInt(1, cid);
				resultSet = pstmt.executeQuery();
				if (resultSet != null && resultSet.next()) {
						allCartoon cartoon = new allCartoon();
						cartoon.setCid(resultSet.getInt("cid"));
						cartoon.setTypeid(resultSet.getInt("typeid"));
						cartoon.setCtitle(resultSet.getString("ctitle"));
						cartoon.setCauthor(resultSet.getString("cauthor"));
						cartoon.setContent(resultSet.getString("content"));
						cartoon.setPic(resultSet.getString("pic"));
						cartoon.setUrl(resultSet.getString("url"));
						cartoon.setIssueDate(resultSet.getDate("issuedate"));
						cartoon.setUpdatesLot(resultSet.getString("updateslot"));
						cartoon.setIssure(resultSet.getString("issuer"));
						cartoon.setPublish(resultSet.getString("publish"));
						cartoon.setStock(resultSet.getInt("stock"));
						cartoon.setNum_Of_Visit(resultSet.getInt("num_of_visit"));
						return cartoon;
				}
				return null;
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				return null;
			}finally{
				BaseDAO.close(connection, pstmt, resultSet);
			}
		}
	}
	//��������
	public int addCartoon(allCartoon allcartoon){
		Connection connection = BaseDAO.getConnection();
		int row = 0;
		if (connection == null) {
			return row;
		}else {
			PreparedStatement pstmt = null;
			ResultSet resultSet = null;
			
			try {
				String sql = "insert into cartoon(typeid,ctitle,cauthor,content,pic,url,issuedate,updateslot,issuer,publish,stock) values(?,?,?,?,?,?,?,?,?,?,?)";
				pstmt = connection.prepareStatement(sql);
				pstmt.setInt(1, allcartoon.getTypeid());
				pstmt.setString(2, allcartoon.getCtitle());
				pstmt.setString(3, allcartoon.getCauthor());
				pstmt.setString(4, allcartoon.getContent());
				pstmt.setString(5, allcartoon.getPic());
				pstmt.setString(6, allcartoon.getUrl());
				pstmt.setDate(7, allcartoon.getIssueDate());
				pstmt.setString(8, allcartoon.getUpdatesLot());
				pstmt.setString(9, allcartoon.getIssure());
				pstmt.setString(10, allcartoon.getPublish());
				pstmt.setInt(11, allcartoon.getStock());
				row = pstmt.executeUpdate();
				return row;
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				return row;
			}finally{
				BaseDAO.close(connection, pstmt, resultSet);
			}
		}
	}
	//����cid�޸�����
	public int updateCartoon(int num_of_visit, int cid){
		Connection connection = BaseDAO.getConnection();
		int row = 0;
		if (connection == null) {
			return row;
		}else {
			PreparedStatement pstmt = null;
			ResultSet resultSet = null;
			
			try {
				String sql = "update cartoon set num_of_visit = ? where cid = ?";
				pstmt = connection.prepareStatement(sql);
				pstmt.setInt(1, num_of_visit);
				pstmt.setInt(2, cid);
				row = pstmt.executeUpdate();
				return row;
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}finally{
				BaseDAO.close(connection, pstmt, resultSet);
			}
		}
		return row;
	}
	
	//����cidɾ������
	public int deleteCartoon(int cid){
		Connection connection = BaseDAO.getConnection();
		int row = 0;
		if (connection == null) {
			return row;
		}else {
			PreparedStatement pstmt = null;
			String sql = "delete from cartoon where cid = ?";
			
			try {
				pstmt = connection.prepareStatement(sql);
				pstmt.setInt(1, cid);
				row = pstmt.executeUpdate();
				return row;
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}finally{
				BaseDAO.close(connection, pstmt, null);
			}
		}
		return row;
	}
	//������Ϣ�޸�
	public int updateAllCartoon(allCartoon allcartoon){
		Connection connection = BaseDAO.getConnection();
		int row = 0;
		if (connection == null) {
			return row;
		}else {
			PreparedStatement preparedStatement = null;
			ResultSet resultSet = null;
			
			try {
				String sql = "update cartoon set publish = ?,updatesLot = ?,stock = ?,content = ? where cid = ?";
				preparedStatement = connection.prepareStatement(sql);
				preparedStatement.setString(1, allcartoon.getPublish());
				preparedStatement.setString(2, allcartoon.getUpdatesLot());
				preparedStatement.setInt(3, allcartoon.getStock());
				preparedStatement.setString(4, allcartoon.getContent());
				preparedStatement.setInt(5, allcartoon.getCid());
				row = preparedStatement.executeUpdate();
				return row;
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}finally{
				BaseDAO.close(connection, preparedStatement, resultSet);
			}
		}
		return row;
	}
}
