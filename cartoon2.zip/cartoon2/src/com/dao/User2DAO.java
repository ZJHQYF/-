package com.dao;

import java.sql.ResultSet;

import com.entity.User2;
import com.mysql.jdbc.Connection;
import com.mysql.jdbc.PreparedStatement;
//ʵ�ֶ�user2��������ݴ�ȡ����

public class User2DAO {
	//����
	
	//ɾ��
	
	//����
	
	//��ѯ
	public User2 select (String name, String pwd){
		//һ��������
		Connection con = BaseDAO.getConnection();
		if (con == null) {
			return null;
		}else{
			PreparedStatement pstmt = null;
			ResultSet rs = null;
			try {
				String sql = "select * from user2 where username = ? and userpwd = ?";
				pstmt = (PreparedStatement) con.prepareStatement(sql);
				pstmt.setString(1, name);
				pstmt.setString(2, pwd);
				rs = pstmt.executeQuery();
				if (rs != null && rs.next()) {
					User2 user2 = new User2();
					user2.setUsername(rs.getString("username"));
					user2.setUserpwd(rs.getString("userpwd"));
					user2.setSex(rs.getString("sex"));
					user2.setBeizgu(rs.getString("beizhu"));
					user2.setId(rs.getInt("id"));
					return user2;
				}else {
					return null;
				}
			} catch (Exception e) {
				// TODO: handle exception
				return null;
			}finally{
				//6 �رղ��������ùرշ���
				BaseDAO.close(con, pstmt, rs);
			}
		}
	}
}
