package com.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import com.entity.CartoonType;

public class CartoonTypeDAO {
	private Connection connection = BaseDAO.getConnection();
	//��ѯ������������
	public ArrayList<CartoonType> selectCartoonTypes(){
		if (connection == null) {
			return null;
		}else {
			Statement statement = null;
			ResultSet resultSet = null;
			
			try {
				String sql = "select * from cartoontype";
				statement = connection.createStatement();
				resultSet = statement.executeQuery(sql);
				if (resultSet != null) {
					ArrayList<CartoonType> cartoonTypeList = new ArrayList<CartoonType>();
					while (resultSet.next()) {
						CartoonType cartoonType = new CartoonType();
						cartoonType.setTypeId(resultSet.getInt("typeid"));
						cartoonType.setTypeName(resultSet.getString("typename"));
						cartoonTypeList.add(cartoonType);	
					}
					return cartoonTypeList;
				}
				return null;
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				return null;
			}finally{
				BaseDAO.close(connection, null, resultSet);
			}
		}
	}
	//����typeid��ѯ
	public CartoonType selectCartoonTypeToTypsid(int typeid){
		Connection connection = BaseDAO.getConnection();
		if (connection == null) {
			return null;
		}else {
			PreparedStatement pstmt = null;
			ResultSet resultSet = null;
			
			try {
				String sql = "select * from cartoontype where typeid = ?";
				pstmt = connection.prepareStatement(sql);
				pstmt.setInt(1, typeid);
				resultSet = pstmt.executeQuery();
				if (resultSet != null && resultSet.next()) {
					CartoonType cartoonType = new CartoonType();
					cartoonType.setTypeId(resultSet.getInt("typeid"));
					cartoonType.setTypeName(resultSet.getString("typename"));
					return cartoonType;
				}
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				return null;
			}finally{
				BaseDAO.close(connection, pstmt, resultSet);
			}
		}
		return null;
	}
	//����typeidΪ�������޸�������
	public int updateCartoonType(int typeId, String typeName){
		Connection connection = BaseDAO.getConnection();
		int row = 0;
		if (connection != null) {
			PreparedStatement pstmt = null;
			try {
				System.out.println("�Ƿ�����޸�");
				System.out.println("Dao�У�" + typeId);
				System.out.println("Dao�У�" + typeName);
				String sql = "update cartoontype set typename = ? where typeid = ?";
				pstmt = connection.prepareStatement(sql);
				pstmt.setInt(2, typeId);
				pstmt.setString(1, typeName);
				row = pstmt.executeUpdate();
				return row;
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				return row;
			}finally{
				BaseDAO.close(connection, pstmt, null);
			}
			}else {
			return row;
		}
	}
	
	//����typeidɾ����������
	public int deleteCartoonType(int typeId){
		Connection connection = BaseDAO.getConnection();
		int row = 0;
		if (connection != null) {
			PreparedStatement pstmt = null;
			
			try {
				String sql = "delete from cartoontype where typeid = ?";
				pstmt = connection.prepareStatement(sql);
				pstmt.setInt(1, typeId);
				row = pstmt.executeUpdate();
				return row;
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				return row;
			}finally{
				BaseDAO.close(connection, pstmt, null);
			}
		}else {
			return row;
		}
	}
	//������������
	public int insertCartoonType(CartoonType cartoonType){
		Connection connection = BaseDAO.getConnection();
		int row = 0;
		if (connection != null) {
			PreparedStatement pstmt = null;
			try {
				String sql = "insert into cartoontype(typename) values(?)";
				pstmt = connection.prepareStatement(sql);
				pstmt.setString(1, cartoonType.getTypeName());
				row = pstmt.executeUpdate();
				return row;
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				return row;
			}finally{
				BaseDAO.close(connection, pstmt, null);
			}
		}else {
			return row;
		}
	}
}
