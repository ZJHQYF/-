function $(id){
	return document.getElementById(id);
}
function decide(){
	var textarea = $('textarea').value;
	console.log(textarea.length);
	var s = $('select').value;
	if(s == '0'){
		alert("请先选择漫画类型！");
		return false;
	}else{
		if(textarea.length == 0){
			if(confirm("漫画简介未填写，确认提交吗？")){
				return true;
			}else{
				$('textarea').focus();
				return false;
			}
		}else if(textarea.length > 200){
			alert("简介字数不能多于200字！");
			$('textarea').focus();
			return false;
		}
	}
	
};