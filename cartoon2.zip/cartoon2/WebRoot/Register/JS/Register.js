function validate(){
			var pwd1 = document.getElementById("pass1_input");
			var pwd2 = document.getElementById("pass2_input");
			if (pwd1.value != pwd2.value){
				alert("两次输入的密码不一致！");
				return false;
			}
			if (pwd1.value.length < 6 || pwd1.value.length > 16){
				alert("请注意密码长度！");
				pwd1.select();
				pwd1.focus();
				return false;
			};
		}
		var isShow = true;
		function change(){
			var v = document.getElementById("pass1_input");
			var button_value = document.getElementById("button_input");
			if(isShow){
				v.type = "text";
				button_input.value = "隐藏密码";
				isShow = false;
				
			}else{
				v.type = "password";
				button_input.value = "显示密码";
				isShow = true;
			};
			
		}