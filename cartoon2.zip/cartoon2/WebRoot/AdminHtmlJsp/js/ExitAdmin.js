function exit_admin(){
	if(confirm("确认退出管理员账号吗？")){
		return true;
	}else{
		return false;
	}
}