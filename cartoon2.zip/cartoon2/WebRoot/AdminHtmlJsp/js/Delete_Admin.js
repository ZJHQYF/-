﻿
function delete_list(){
	if(confirm("确认删除此条数据吗？")){
		return true;
	}else{
		return false;
	}
}

