window.onload = function(){
	function $(id){
		return document.getElementById(id);
	};
	function addWeight(){
		$('add_button').style.width = "150px";
		$('add_button').style.marginLeft = "0px";
		$('add_content').style.height = "50px";
		$('add_content').style.fontSize = "15px";
		$('add_content').style.opacity = "1";
		$('add_content').style.right = "10px";
	};
	function minusWeight(){
		$('add_button').style.width = "50px";
		$('add_button').style.marginLeft = "50px";
		$('add_content').style.opacity = "0";
		$('add_content').style.height = "0";
		$('add_content').style.fontSize = "0";
		$('add_content').style.right = "0px";
	};
	$('add_button').onmouseover = addWeight;
	$('add_button').onmouseout = minusWeight;
};

