/*轮播图逻辑代码*/
window.onload = function(){
		var container = document.getElementById('lunbotu');//获取容器
		var prev = document.getElementById('prev');//获得左按钮
		var next = document.getElementById('next');//获得右按钮
		//获取五个小圆点
		var buttons = document.getElementById('buttons').getElementsByTagName('span');
		//获取图片列表
		var list = document.getElementById('list');
		var index = 1;
		var timer;//存放定时器
		//存储动画是否在运行的状态的变量
		var animated = false;
		//点亮小圆点函数
		function showButton(){
			//遍历一下buttons中的每一个元素，如果buttons[i].className == 'no' 就去掉循环，然后退出循环
			for(var i = 0; i < buttons.length; i++){
				if(buttons[i].className == 'on'){
					buttons[i].className = '';
					break;
				}
			}
			buttons[index - 1].className = 'on';
		}
		function animate(offset){
			animated = true;
			var newLeft = parseInt(list.style.left) + offset;
			var time = 300;//位移总时间
			var interval = 5; //位移间隔时间
			var speed = offset / (time / interval);//（每次大的位移，计算得出小的位移）位移量除位移次数得出每一次的位移量
			//判断一下，什么情况下再做位移
			function go(){
			//speed小于0表示向左移动 ,然后判断left只是否大于目标值（只有大于的时候，才让他向右滚动）
				if((speed < 10 && parseInt(list.style.left) > newLeft) || (speed>0 && parseInt(list.style.left) < newLeft)){
					list.style.left = parseInt(list.style.left) + speed + 'px';
					//10ms后再次调佣go()函数，用到定时器，setTimeout
					setTimeout(go,interval);//setTimeout定时器只会执行一次
				}else{
						animated = false;
						list.style.left = newLeft + 'px';
						if(newLeft > -972){
						list.style.left = -4860 + 'px';
						}
						if(newLeft < -4860){
						list.style.left = -972 + 'px';
						}
				}
			}
			go();
			
			
		}
		
		
		//自动切换，切换部分代码
		//开始自动轮播
		function play(){
			timer = setInterval(function(){
				next.onclick();//触发点击右箭头事件
			},4000);//这个定时器是每隔一段时间运行一次
		}
		//停止自动轮播
		function stop(){
			clearInterval(timer);
		}
		prev.onclick = function(){
		if(!animated){
			if(index == 1){
				index = 5;
			}else{
				index -= 1;
			}
			
			
			
			animate(972);
			showButton();
			}
			
		};
		next.onclick = function(){
		if(!animated){
			if(index == 5){
				index = 1;
			}else{
				index += 1;
			}
			
			showButton();
				animate(-972);
				
		
		}
			
		};
		//小圆点的点击事件
		for(var j = 0; j < buttons.length; j++){
			buttons[j].onclick = function(){
			if(this.className == 'on'){
				return;
			}
			//getAttribute取得自定义属性
				var myIndex = parseInt(this.getAttribute('index'));
				//求出偏移量
				var offset = -972 * (myIndex - index);//每次点击小圆点时的偏移量
				animate(offset);
				index = myIndex;
				showButton();
			};
		}
		play();
		//当鼠标移动到放有轮播图的盒子上时，自动轮播停止
		container.onmouseover = stop;
		//当鼠标移开，自动轮播开始
		container.onmouseout = play;
	};